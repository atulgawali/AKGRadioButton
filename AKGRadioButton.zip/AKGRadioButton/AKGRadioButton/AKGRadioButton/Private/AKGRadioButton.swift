//
//  AKGRadioButton.swift
//  AKGRadioButton
//
//  Created by Atul Gawali on 02/02/17.
//  Copyright © 2017 Atul Gawali. All rights reserved.
//

import UIKit

class AKGRadioButton: UIButton {
    var buttonTitle : String
    var buttonTag : Int
    
    init(frame: CGRect,buttonTitle : String, buttonTag : Int) {
        self.buttonTitle = buttonTitle
        self.buttonTag = buttonTag
        super.init(frame : frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    

}
