//
//  AKGTableView.swift
//  AKGRadioButton
//
//  Created by Atul Gawali on 04/02/17.
//  Copyright © 2017 Atul Gawali. All rights reserved.
//

import UIKit

class AKGTableView: UITableView {
    override init(frame: CGRect, style: UITableViewStyle) {
        super.init(frame: frame, style: UITableViewStyle.plain)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
