//
//  AKGRadioButtonGroupView.swift
//  AKGRadioButton
//
//  Created by Atul Gawali on 02/02/17.
//  Copyright © 2017 Atul Gawali. All rights reserved.
//

import UIKit

protocol ProtocolDelegate {
    func selectedResult(resultObject:AKGRadioButtonModel)
}

class AKGRadioButtonGroupView: UIView ,UITableViewDelegate,UITableViewDataSource{
    var akgRadioButtonModel : [AKGRadioButtonModel]
    var akgRadioButtonGroupName : String
    var akgRadioButtonGroupPosstion : CGPoint
    var akgTableView : AKGTableView
    var delegate: ProtocolDelegate?
    
    init(akgRadioButtonModel : [AKGRadioButtonModel] ,akgRadioButtonGroupName : String ,akgRadioButtonGroupPosstion : CGPoint) {
        let customHeight : CGFloat = CGFloat(akgRadioButtonModel.count * 44) + 30
        let frame = CGRect(x: akgRadioButtonGroupPosstion.x, y: akgRadioButtonGroupPosstion.y, width: 200, height: customHeight)
        self.akgRadioButtonModel = akgRadioButtonModel
        self.akgRadioButtonGroupName = akgRadioButtonGroupName
        self.akgRadioButtonGroupPosstion = akgRadioButtonGroupPosstion
        akgTableView = AKGTableView(frame: CGRect(x: 0 , y: 0, width: frame.size.width, height:frame.size.height), style: UITableViewStyle.plain)
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func setupView(){
        self.backgroundColor = UIColor.darkGray
        akgTableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        akgTableView.delegate = self
        akgTableView.dataSource = self
        akgTableView.separatorColor = UIColor.clear
        akgTableView.allowsSelection = false
        self.addSubview(akgTableView)
        
        let view1: UIView = UIView.init(frame: CGRect(x: 0, y: 0, width: akgTableView.frame.size.width, height: 30));
        let label: UILabel = UILabel.init(frame: CGRect(x: 0, y: 0, width: akgTableView.frame.size.width, height: 30))
        label.text = "  "+self.akgRadioButtonGroupName
        view1.addSubview(label);
        akgTableView.tableHeaderView = view1;
    }
    
    func buttonAction(akgRadioButton: UIButton!) {
        let selectedMode  = self.akgRadioButtonModel [akgRadioButton.tag]
        for model in self.akgRadioButtonModel{
            if self.akgRadioButtonModel [akgRadioButton.tag] .isEqual(model) {
                model.selected = true
            }
            else{
                model.selected = false
            }
        }
        akgTableView.reloadData()
        delegate?.selectedResult(resultObject: selectedMode)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return akgRadioButtonModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:UITableViewCell=UITableViewCell(style: UITableViewCellStyle.subtitle, reuseIdentifier: "cell")
        setupCell(cell: cell, akgModelObject: akgRadioButtonModel [indexPath.row],indexPath: indexPath)
        return cell;
    }
    
    func setupCell(cell : UITableViewCell ,akgModelObject : AKGRadioButtonModel ,indexPath : IndexPath){
        let akgRadioButton = AKGRadioButton(frame: CGRect(x: 20, y: 10, width: 100, height: 24), buttonTitle: akgModelObject.lblText, buttonTag:indexPath.row)
        akgRadioButton.setTitle(akgModelObject.lblText, for: UIControlState.normal)
        akgRadioButton.addTarget(self, action:#selector(self.buttonAction), for: .touchUpInside)
        akgRadioButton.contentHorizontalAlignment = .left
        akgRadioButton.tag = indexPath.row;
        akgRadioButton.setTitleColor(UIColor.black, for: .normal)
        if akgModelObject.selected {
            akgRadioButton.setImage(UIImage(named: "select.png"), for: UIControlState.normal)
        }
        else{
            akgRadioButton.setImage(UIImage(named: "unSelect.png"), for: UIControlState.normal)
        }
        cell.addSubview(akgRadioButton)
    }
    
}


