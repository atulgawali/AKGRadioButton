//
//  AKGViewController.swift
//  AKGRadioButton
//
//  Created by Atul Gawali on 02/02/17.
//  Copyright © 2017 Atul Gawali. All rights reserved.
//

import UIKit

class AKGViewController: UIViewController ,ProtocolDelegate{
        
    
    var akgRadioButtonModel: [AKGRadioButtonModel]? = nil
    var  akgRBGroupView : AKGRadioButtonGroupView? = nil
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        setupUI()
    }
    
    func setupUI()  {
        //initialse Array
        akgRadioButtonModel = [AKGRadioButtonModel]()
        
        
        //make radiobutton object
        let maleButton = AKGRadioButtonModel(lblText : "Male" ,identifire : "Male" ,selected : true)
        let femaleButton = AKGRadioButtonModel(lblText : "Female" ,identifire : "Female" ,selected : false)
        let gayButton = AKGRadioButtonModel(lblText : "Other" ,identifire : "Other" ,selected : false)

        akgRadioButtonModel!.insert(maleButton, at: 0)
        akgRadioButtonModel!.insert(femaleButton, at: 1)
        akgRadioButtonModel!.insert(gayButton, at: 2)

        //where you want to add jsit pass x and y point
        let size = CGPoint(x: 30, y: 130)
        
        //make view object and setup view
        let  akgRBGroupView = AKGRadioButtonGroupView(akgRadioButtonModel : akgRadioButtonModel! ,akgRadioButtonGroupName : "Gender" , akgRadioButtonGroupPosstion : size)
        akgRBGroupView.setupView()
        akgRBGroupView.delegate = self
        self.view.addSubview(akgRBGroupView)
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //result will got here...
    func selectedResult(resultObject:AKGRadioButtonModel){
        print("Selected Radio Button -> \(resultObject.lblText)")
    }
    
}

